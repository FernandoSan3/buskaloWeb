  <div class="tab-pane" id="opportunityaccept">
                  <div class="opportunity-sec">
                    <div class="side-heading">
                      <div class="row">
                        <div class="col-md-8">
                          <div class="head-side">
                            <h3>Opportunidades</h3>
                          </div>
                        </div>
                        <div class="col-md-4">
                          <div class="search-side">
                            <input type="text" name="" placeholder="Search">
                            <i class="fa fa-search"></i>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-12">
                        <div class="opportunity-detail">
                          <div class="oppd-icon">
                            <img src="img/star-w.png">
                          </div>
                          <h5 class="orange">Nuevo</h5>
                          <span>Jueves, 28 de Abril - 19h30</span>

                          <h2>Requerimiento de Instalacion</h2>
                          <p>Se solicita personal para realizar Conexion electrica de puntos de Luz e interrpuptorea para nuevo departamento mismo que consta de 2 habitaciones, cocina, sala, bano, y lobby.</p>

                          <span>Cliente: Maria  Paz Espinoza/Guayaquil</span>
                        </div>

                        <div class="col-md-12 btn-div">
                          <button type="button" class="btn opp-btn">Comprar</button>
                          <button type="button" class="btn opp-btn ignore-btn">Ignorar</button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>