<div id="sidebar-wrapper">
    <ul class="nav nav-tabs sidebar-nav">
       {{-- <li class="nav-item">
        <a class="nav-link" href="{{route('frontend.contractor.co-dashoard')}}">
          <i class="fa fa-home"></i> Homepage</a>
          <a href="#" class="side-counter"><span>2</span></a>
       </li> --}}

      <li class="nav-item">
        <a class="nav-link" href="{{route('frontend.contractor.my-profile')}}">
          <i class="fa fa-user-o"></i> My Profile</a>
          {{-- <a href="#" class="side-counter"><span>1</span></a> --}}
      </li>

		   <li class="nav-item">
			 <a class="nav-link" href="{{route('frontend.contractor.opportunities')}}"><i class="fa fa-star-o"></i> opportunity</a>
          <a href="#" class="side-counter"><span>7</span></a>
		  </li>

       <li class="nav-item">
        <a class="nav-link" href="{{route('frontend.contractor.jobs')}}">
          <i class="fa fa-briefcase"></i> Jobs</a>
          <a href="#" class="side-counter"><span>3</span></a>
      </li>
       <li class="nav-item">
        <a class="nav-link" href="{{route('frontend.contractor.message')}}">
          <i class="fa fa-envelope-o"></i> Message</a>
          <a href="#" class="side-counter"><span>1</span></a>
      </li>
      
      {{-- <li class="nav-item">
        <a class="nav-link" href="{{route('frontend.contractor.services')}}">
        <i class="fa fa-tag"></i> Services offered</a>
      </li> --}}

      <li class="nav-item">
        <a class="nav-link" href="{{route('frontend.contractor.credits')}}">
          <i class="fa fa-credit-card"></i> Credits</a>
      </li>

      {{-- <li class="nav-item">
        <a class="nav-link" href="{{route('frontend.contractor.documents')}}">
          <i class="fa fa-file-o"></i> Documentation</a>
      </li> --}} 

       <!-- <li class="nav-item">
        <a class="nav-link" href="{{--route('frontend.contractor.workers')--}}">Workers</a>
      </li> -->
    </ul>
  </div>




